<!DOCTYPE html>
<html>

<head>
    <title>Data Sensor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.1/chart.min.js"></script>
    <script>
        // Fungsi untuk mengambil waktu saat ini
        function getCurrentTime() {
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();
            var seconds = currentTime.getSeconds();

            // Tambahkan angka 0 di depan jam, menit, dan detik jika hanya satu digit
            hours = (hours < 10 ? "0" : "") + hours;
            minutes = (minutes < 10 ? "0" : "") + minutes;
            seconds = (seconds < 10 ? "0" : "") + seconds;

            // Format waktu dalam HH:MM:SS
            var formattedTime = hours + ":" + minutes + ":" + seconds;

            // Mengupdate elemen dengan id "current-time" dengan waktu saat ini
            document.getElementById("current-time").innerHTML = "Waktu saat ini: " + formattedTime;
        }

        // Fungsi untuk menggambar grafik
        function drawChart(data) {
            var ctx = document.getElementById('chart').getContext('2d');
            var labels = [];
            var PhValues = [];

            // Membuat array label waktu dan nilai LDR dari data
            data.forEach(function (item) {
                labels.push(item.timestamp);
                PhValues.push(item.Ph_value);
            });

            var chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Nilai Ph',
                        data: PhValues,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Memperbarui grafik dan tabel setiap detik
        function updateChartAndTable() {
            fetch('<?php echo base_url("sensor/get_sensor_data"); ?>')
                .then(response => response.json())
                .then(data => {
                    drawChart(data);
                    updateTable(data);
                });
        }

        // Fungsi untuk memperbarui tabel data
        function updateTable(data) {
            var table = document.querySelector('table');
            var tbody = table.querySelector('tbody');
            tbody.innerHTML = '';

            data.forEach(function (item) {
                var row = document.createElement('tr');
                row.innerHTML = '<td>' + item.id + '</td><td>' + item.Ph_value + '</td><td>' + item.timestamp + '</td>';
                tbody.appendChild(row);
            });
        }

        // Load everything after the page has loaded
        window.onload = function () {
            getCurrentTime();
            updateChartAndTable();
            setInterval(function () {
                getCurrentTime();
                updateChartAndTable();
            }, 1000);
        };
    </script>
</head>

<body>
    <h1>Data Sensor</h1>
    <div id="current-time"></div>

    <table>
        <tr>
            <th>ID</th>
            <th>Nilai Ph</th>
            <th>Waktu</th>
        </tr>
        <?php foreach ($sensor_data as $data) { ?>
            <tr>
                <td>
                    <?php echo $data->id; ?>
                </td>
                <td>
                    <?php echo $data->Ph_value; ?>
                </td>
                <td>
                    <?php echo $data->timestamp; ?>
                </td>
            </tr>
        <?php } ?>
    </table>
    <canvas id="chart"></canvas>
</body>

</html>