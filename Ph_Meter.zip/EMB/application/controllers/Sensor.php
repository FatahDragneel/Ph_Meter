<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sensor extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('sensor_model'); // Load model
    }

    public function index()
    {
        // Mengambil data sensor dari model
        $data['sensor_data'] = $this->sensor_model->get_sensor_data();

        // Load view untuk menampilkan data sensor
        $this->load->view('sensor_view', $data);
    }

   public function send_sensor_data()
    {
        if ($this->input->post('Phvalue')) {
            $Phvalue = $this->input->post('Phvalue');
            $this->sensor_model->insert_sensor_data($Phvalue); // Memasukkan data sensor ke dalam database

            // Tambahkan respons HTTP untuk memberi tahu Arduino bahwa data berhasil diterima
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['status' => 'success']));
        } else {
            // Tambahkan respons HTTP jika data tidak diterima dengan benar
            $this->output
                ->set_status_header(400)
                ->set_content_type('application/json')
                ->set_output(json_encode(['status' => 'error']));
        }
    }


    public function get_sensor_data()
    {
        $sensor_data = $this->sensor_model->get_sensor_data();
        header('Content-Type: application/json');
        echo json_encode($sensor_data);
    }

}
?>