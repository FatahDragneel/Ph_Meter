<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sensor_model extends CI_Model
{
    public function insert_sensor_data($Phvalue)
    {
        $data = array(
            'Ph_value' => $Phvalue
        );

        // Memasukkan data ke dalam tabel 'Ph_data'
        $this->db->insert('ph_data', $data);
    }
    
    public function get_sensor_data()
    {
        // Mengambil data sensor dari tabel 'Ph_data'
        $query = $this->db->get('ph_data');
        return $query->result();
    }

    public function __construct()
    {
        parent::__construct();
    
        if (!$this->db->conn_id) {
            die("Database Connection Error");
        }
    }
}

?>